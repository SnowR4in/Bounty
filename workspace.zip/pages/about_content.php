<div class="prose max-w-none text-zinc-300">
    <h2 class="text-zinc-100">About USDTFaucet</h2>
    <p>USDTFaucet is a free rewards platform where members earn Tether (USDT) &mdash; the world&rsquo;s leading stablecoin &mdash; by completing simple tasks: viewing PTC ads, watching videos, solving shortlinks, completing tasks, spinning the wheel of fortune and claiming from our faucet.</p>
    <p>All balances and withdrawals are handled in USDT through <a href="https://faucetpay.io/" target="_blank" rel="noopener" class="text-primary hover:text-primaryHover transition-colors">FaucetPay</a>, a leading micro-wallet for cryptocurrency faucets. Because USDT is a stablecoin pegged 1-to-1 to the US dollar, everything you earn keeps its value &mdash; no volatility, what you earn is what you keep.</p>
    <h3 class="text-zinc-100">Why Tether USDT?</h3>
    <ul>
        <li><strong>Stable value</strong> &mdash; 1 USDT is designed to always equal 1 US dollar.</li>
        <li><strong>Instant payouts</strong> &mdash; withdrawals are sent through the FaucetPay API in seconds.</li>
        <li><strong>Low minimum withdrawal</strong> &mdash; cash out small amounts without long waits.</li>
        <li><strong>Log in with your FaucetPay email</strong> &mdash; no wallet address hassle, your payouts go straight to your FaucetPay account.</li>
    </ul>
</div>
