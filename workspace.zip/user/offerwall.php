<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: /login');
    exit;
}

require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/site_settings.php';
$settings = get_site_settings($pdo);

if (!offerwall_page_enabled($settings)) {
    header('Location: /user/');
    exit;
}

$user_id = intval($_SESSION['user_id']);
$api_key = trim((string)($settings['offerwall_api_key'] ?? ''));
$secret  = trim((string)($settings['offerwall_secret_key'] ?? ''));
$owme_on = isset($settings['offerwall_enabled']) && $settings['offerwall_enabled'] == '1';
$ou_on   = ou_is_enabled($settings);

$signedUrl = '';
$config_error = '';
if ($owme_on) {
    if ($api_key === '' || $secret === '') {
        $config_error = 'Offerwall.me is not configured yet. Please check back later.';
    } else {
        $signedUrl = owme_signed_url($api_key, (string)$user_id, $secret);
    }
}

$ou_walls = $ou_on ? ou_walls_for_user($settings, $user_id) : [];

include 'includes/header.php';
?>

<div class="relative z-10 pt-24 pb-16 min-h-screen">
    <div class="container-custom">
        <div class="flex flex-col md:flex-row md:items-center justify-between mb-8 gap-4">
            <div>
                <div class="section-label">Earn</div>
                <h1 class="text-3xl font-extrabold text-zinc-100 tracking-tight mt-2">Offerwall</h1>
                <p class="text-zinc-500 mt-2">Complete offers and surveys to earn USDT. Rewards are credited automatically.</p>
            </div>
        </div>

        <?php if ($ou_on): ?>
            <div class="mb-10">
                <h2 class="text-lg font-bold text-zinc-100 mb-4">Survey Walls</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                    <?php foreach ($ou_walls as $wall): ?>
                        <a href="<?php echo htmlspecialchars($wall['url'], ENT_QUOTES, 'UTF-8'); ?>" target="_blank" rel="noopener noreferrer" class="bg-surface-card rounded-lg border border-white/10 overflow-hidden hover:border-white/20 transition-colors group flex flex-col h-full micro-anim">
                            <div class="bg-surface-raised relative w-full flex-shrink-0 flex items-center justify-center overflow-hidden" style="height: 110px;">
                                <i class="fa-solid <?php echo htmlspecialchars($wall['icon']); ?> text-4xl text-primary/40"></i>
                                <div class="absolute top-2 right-2 bg-black/60 backdrop-blur-md text-zinc-300 text-[8px] font-bold px-1.5 py-0.5 rounded uppercase tracking-wide z-10 font-mono">
                                    Survey
                                </div>
                            </div>
                            <div class="p-4 flex flex-col flex-grow">
                                <h3 class="text-sm font-bold text-zinc-100 leading-tight mb-1 truncate"><?php echo htmlspecialchars($wall['name']); ?></h3>
                                <p class="text-[11px] text-zinc-500 mb-3"><?php echo htmlspecialchars($wall['description']); ?></p>
                                <div class="mt-auto flex items-center justify-between">
                                    <span class="text-[10px] text-primary uppercase tracking-wider font-semibold font-mono">Start Survey</span>
                                    <div class="w-6 h-6 bg-primary/10 text-primary rounded-full flex items-center justify-center group-hover:bg-primary group-hover:text-zinc-950 transition-colors">
                                        <i class="fa-solid fa-arrow-right text-[10px]"></i>
                                    </div>
                                </div>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($owme_on): ?>
            <?php if ($config_error !== ''): ?>
                <div class="bg-surface-card rounded-lg border border-white/10 p-12 text-center">
                    <i class="fa-solid fa-table-cells text-5xl text-zinc-600 mb-4 block"></i>
                    <h2 class="text-xl font-bold text-zinc-100 mb-2">Offerwall Unavailable</h2>
                    <p class="text-zinc-500"><?php echo htmlspecialchars($config_error); ?></p>
                </div>
            <?php else: ?>
                <div class="bg-surface-card rounded-lg border border-white/10 overflow-hidden">
                    <iframe
                        src="<?php echo htmlspecialchars($signedUrl, ENT_QUOTES, 'UTF-8'); ?>"
                        scrolling="yes"
                        frameborder="0"
                        style="width:100%;height:800px;border:0;"
                        title="Offerwall.me"
                    ></iframe>
                </div>
            <?php endif; ?>
        <?php elseif (!$ou_on): ?>
            <div class="bg-surface-card rounded-lg border border-white/10 p-12 text-center">
                <i class="fa-solid fa-table-cells text-5xl text-zinc-600 mb-4 block"></i>
                <h2 class="text-xl font-bold text-zinc-100 mb-2">Offerwall Unavailable</h2>
                <p class="text-zinc-500">No offerwall providers are enabled.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
