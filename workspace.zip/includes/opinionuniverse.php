<?php

if (!defined('OU_API_BASE')) {
    define('OU_API_BASE', 'https://api.opinionuniverse.com');
}

if (!defined('OU_DEFAULT_APP_ID')) {
    define('OU_DEFAULT_APP_ID', 'ID_d1c94cda94189d2d3b41633b7289c70c');
}

if (!defined('OU_DEFAULT_UID')) {
    define('OU_DEFAULT_UID', '4157');
}

if (!defined('OU_POSTBACK_IP')) {
    define('OU_POSTBACK_IP', '147.79.123.200');
}

if (!function_exists('ou_survey_walls')) {
    function ou_survey_walls(): array {
        return [
            'dynata' => [
                'slug'        => 'dynata',
                'name'        => 'Dynata',
                'offer_id'    => '3063128',
                'description' => 'Complete professional surveys from Dynata and earn USDT.',
                'icon'        => 'fa-clipboard-list',
            ],
            'bitlab' => [
                'slug'        => 'bitlab',
                'name'        => 'Bitlab',
                'offer_id'    => '6301974',
                'description' => 'Take Bitlab surveys matched to your profile and get credited automatically.',
                'icon'        => 'fa-flask',
            ],
            'cpx' => [
                'slug'        => 'cpx',
                'name'        => 'CPX Research',
                'offer_id'    => '4314257',
                'description' => 'Answer CPX Research surveys. Rewards are sent via secure postback.',
                'icon'        => 'fa-comments',
            ],
        ];
    }
}

if (!function_exists('ou_app_id')) {
    function ou_app_id(array $settings): string {
        $id = trim((string)($settings['ou_app_id'] ?? ''));
        return $id !== '' ? $id : OU_DEFAULT_APP_ID;
    }
}

if (!function_exists('ou_publisher_uid')) {
    function ou_publisher_uid(array $settings): string {
        $uid = trim((string)($settings['ou_uid'] ?? ''));
        return $uid !== '' ? $uid : OU_DEFAULT_UID;
    }
}

if (!function_exists('ou_is_enabled')) {
    function ou_is_enabled(array $settings): bool {
        return isset($settings['ou_enabled']) && $settings['ou_enabled'] == '1';
    }
}

if (!function_exists('ou_click_id')) {
    function ou_click_id(int $user_id): string {
        return $user_id . '_' . bin2hex(random_bytes(8));
    }
}

if (!function_exists('ou_user_id_from_sid')) {
    function ou_user_id_from_sid(string $sid): int {
        $sid = trim($sid);
        if ($sid !== '' && ctype_digit($sid)) {
            return (int)$sid;
        }
        if (preg_match('/^(\d+)_/', $sid, $m)) {
            return (int)$m[1];
        }
        return 0;
    }
}

if (!function_exists('ou_click_url')) {
    function ou_click_url(array $settings, string $offer_id, int $user_id, string $sid, string $sid2 = ''): string {
        $params = [
            'app_id'   => ou_app_id($settings),
            'offer_id' => $offer_id,
            'uid'      => ou_publisher_uid($settings),
            'sid'      => $sid !== '' ? $sid : (string)$user_id,
        ];
        $source = $sid2 !== '' ? $sid2 : trim((string)($settings['ou_source_id'] ?? ''));
        if ($source !== '') {
            $params['sid2'] = $source;
        }
        return OU_API_BASE . '/offerwall/clickTrackingLink?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);
    }
}

if (!function_exists('ou_walls_for_user')) {
    function ou_walls_for_user(array $settings, int $user_id): array {
        $source = trim((string)($settings['ou_source_id'] ?? 'offerwall'));
        $walls = [];
        foreach (ou_survey_walls() as $wall) {
            $sid = ou_click_id($user_id);
            $sid2 = $source !== '' ? $source : $wall['slug'];
            $wall['sid'] = $sid;
            $wall['url'] = ou_click_url($settings, $wall['offer_id'], $user_id, $sid, $sid2);
            $walls[] = $wall;
        }
        return $walls;
    }
}

if (!function_exists('ou_verify_sig')) {
    function ou_verify_sig(string $secret, string $sid, string $offer_id, string $payout, string $status, string $sig): bool {
        if ($secret === '' || $sig === '') {
            return false;
        }
        $expected = hash_hmac('sha256', $sid . $offer_id . $payout . $status, $secret);
        return hash_equals($expected, strtolower($sig)) || hash_equals($expected, $sig);
    }
}
